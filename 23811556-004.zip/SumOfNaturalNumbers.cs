﻿using System;


	class SumOfNaturalNumbers
	{
   static void Main()
   {
       Console.Write("Enter the number (n) :");
       int n = Convert.ToInt32(Console.ReadLine());
       int sum = 0;
       for (int i = 0; i <= n; i++)
       {
         sum = sum + i;
       }
       Console.WriteLine($"The sum of numbers from 1 to {n} is : {sum}");
   }
	}

